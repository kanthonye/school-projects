//
//  BufferStream.cpp
//  xmlparser
//
//  Created by Kenneth A Esdaile on 3/17/19.
//  Copyright © 2019 Kenneth A Esdaile. All rights reserved.
//

#include "BufferStream.hpp"
namespace kege{

    long BufferStream::read(char* target, const long size, const char * flags)
    {
        long cnt = 0;
        const char* s, *f;
        for (s=_stream; *s!=0 && cnt<size; s++)
        {
            f = flags;
            while (*f != 0 && *f != *s) f++;
            if (*f != 0) break;
            target[cnt++] = *s;
        }
        target[cnt] = 0;
        long written = s - _stream;
        _stream += written;
        return written;
    }
    
    long BufferStream::copy(char* target, const long size)
    {
        long cnt = 0;
        const char* s;
        for (s=_stream; *s!=0 && cnt<size; s++)
        {
            target[cnt++] = *s;
        }
        return s - _stream;
    }
    
    /**
     @brief  check the sequence of char in str is contain with in stream-buffer
     @return true if found, false otherwise
     */
    long BufferStream::find(const char* str,  const char * flags)
    {
        const char* s, *f;
        const char* a=_stream;
        while (*a != 0)
        {
            s = str;
            if (*s == *a)
            {
                do
                {
                    f = flags;
                    while (*s != *f && *f != 0) f++;
                    if (f != 0) return 0;
                    s++;
                    a++;
                }while (*s == *a && *s!=0 && *a!=0);
                if (s == 0)
                {
                    return a - _stream;
                }
            }
            else
            {
                a++;
            }
        }
        return 0;
    }
    
    /**
     @brief  seek any of the characters in the string 'flag'
     @return total number of characters skipped
     */
    long BufferStream::count(const char * flags)
    {
        const char* f;
        const char* s = _stream;
        while (*s != 0)
        {
            f = flags;
            while (*s != *f && *s != 0 && *f != 0) f++;
            if (*f != 0) break;
            s++;
        }
        return s - _stream;
    }
    
    /**
     @brief  seek and move position any of the characters in the string 'flag'
     @return total number of characters skipped
     */
    long BufferStream::seek(const char * flags)
    {
        const char* f;
        const char* s = _stream;
        while (*s != 0)
        {
            f = flags;
            while (*f != 0)
            {
                if (*s == *f )
                {
                    long n = s - _stream;
                    _stream += n;
                    return n;
                }
                f++;
            }
            s++;
        }
        return 0;
    }
    
    /**
     @brief  skip and move position any characters not in the string 'flag'
     @return total number of characters skipped
     */
    long BufferStream::skip(const char * flags)
    {
        const char* f = flags;
        const char* s = _stream;
        
        while (*s != 0)
        {
            f = flags;
            while (*f != 0 && *s != *f) f++;
            if (*f == 0) break;
            s++;
        }
        
        long n = s - _stream;
        _stream += n;
        return n;
    }
    
    /**
     @brief  check is the first couple of char match char in 'str'
     @return true if match false otherwise
     */
    bool BufferStream::equal(const char * t)
    {
        const char* s = _stream;
        while (*s != 0 && *t != 0) if (*s++ != *t++) return false;
        return true;
    }
    
    /**
     @brief  check is the first couple of char match char in 'str'
     @return true if match false otherwise
     */
    bool BufferStream::cequal(const char * t)
    {
        while (*t != 0)
        {
            if (*_stream == *t++) return true;
        }
        return false;
    }
    
    /**
     @brief  move position to next line
     @return true if match false otherwise
     */
    const char* BufferStream::getln()
    {
        const char* ln = _stream;
        seek("\n");
        if (*_stream == '\n') _stream++;
        return ln;
    }
    
    void BufferStream::operator ++(int)
    {
        if (_stream == nullptr) return;
        if (*_stream == 0) return;
        _stream++;
    }
    
    void BufferStream::operator +=(int n)
    {
        if (_stream == nullptr) return;
        if (*_stream == 0) return;
        _stream += n;
    }
    
    bool BufferStream::LoadText(const ds::string& filename)
    {
        FILE * file = fopen(filename.c_str(), "r");
        if (!file)
        {
            fprintf(stderr,"error: LoadXML(%s) file not found.\n",filename.c_str());
            return false;
        }
        
        fseek(file, 0, SEEK_END);
        size_t filesize = ftell(file);
        rewind(file);
        
        if (filesize == 0) return false;
        _buffer.setsize(filesize);
        
        fread(_buffer.getdata(), filesize, sizeof(char), file);
        _buffer[filesize] = '\0';
        
        SetBufferStream(_buffer);
        return true;
    }
    
    void BufferStream::SetBufferStream(const ds::string& bufr)
    {
        _stream = bufr.c_str();
    }
    
    BufferStream::BufferStream(const BufferStream& stream)
    :   _stream(stream._stream)
    {}
    
    BufferStream::BufferStream()
    :   _stream(nullptr)
    {}
}
