//
//  BufferStream.hpp
//  xmlparser
//
//  Created by Kenneth A Esdaile on 3/17/19.
//  Copyright © 2019 Kenneth A Esdaile. All rights reserved.
//

#ifndef BufferStream_hpp
#define BufferStream_hpp
#include "string.hpp"
#include "Stream.hpp"
namespace kege{
    
    class BufferStream : public Stream
    {
    public:
        
        virtual long read(char* target, const long size, const char * flags);
        
        virtual long copy(char* target, const long size);
        
        /**
         @brief  check the sequence of char in str is contain with in stream-buffer
         @return true if found, false otherwise
         */
        virtual long find(const char* str,  const char * flags);
        
        /**
         @brief  seek any of the characters in the string 'flag'
         @return total number of characters skipped
         */
        virtual long count(const char * flags);
        
        /**
         @brief  seek and move position any of the characters in the string 'flag'
         @return total number of characters skipped
         */
        virtual long seek(const char * flags);
        
        /**
         @brief  skip and move position any characters not in the string 'flag'
         @return total number of characters skipped
         */
        virtual long skip(const char * flags);
        
        /**
         @brief  check is the first couple of char match char in 'str'
         @return true if match false otherwise
         */
        virtual bool equal(const char * t);
        
        /**
         @brief  check is the first couple of char match char in 'str'
         @return true if match false otherwise
         */
        virtual bool cequal(const char * t);
        
        /**
         @brief  check the first char is 'c'
         @return true if match false otherwise
         */
        inline virtual bool equalc(int c)
        {
            return *_stream == c;
        }
        
        /**
         @brief  move position to next line
         @return true if match false otherwise
         */
        virtual const char* getln();
        
        /**
         @brief  move position to next line
         @return true if match false otherwise
         */
        inline virtual char getc()
        {
            _stream++;
            return *_stream;
        }
        
        inline int operator *()
        {
            if (_stream == nullptr) return 0;
            return *_stream;
        }
        
        inline bool end()
        {
            if (_stream == nullptr) return true;
            return *_stream == 0;
        }
        
        void operator ++(int);
        
        void operator +=(int n);
        
        bool LoadText(const ds::string& filename);
        
        void SetBufferStream(const ds::string& bufr);
        
        BufferStream(const BufferStream& stream);
        BufferStream();
        const char* _stream;
        ds::string _buffer;
    };
}
#endif /* BufferStream_hpp */
